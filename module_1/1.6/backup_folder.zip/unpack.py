import shutil


def unpack(archive_path, path_to_unpack):
    pass
